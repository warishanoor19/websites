﻿using System;

namespace HybridArchitectureWeb
{
    // 1. Event Data Class (Jo data hum event ke waqt bhejenge)
    public class UserAuthEventArgs : EventArgs
    {
        public string? UserEmail { get; set; }
        public DateTime TimeStamp { get; set; }
    }

    // 2. Event Publisher (Yeh class event fire karegi)
    public class EventBusService
    {
        public event EventHandler<UserAuthEventArgs>? OnUserLoggedIn;

        public void PublishUserLogin(string email)
        {
            OnUserLoggedIn?.Invoke(this, new UserAuthEventArgs
            {
                UserEmail = email,
                TimeStamp = DateTime.Now
            });
        }
    }

    // 3. Event Listener (Yeh class event sun kar background kaam karegi)
    public class EmailNotificationService
    {
        public EmailNotificationService(EventBusService eventBus)
        {
            // Event ko subscribe kar liya
            eventBus.OnUserLoggedIn += HandleUserLogin;
        }

        private void HandleUserLogin(object? sender, UserAuthEventArgs e)
        {
            // Yahan background task hota hai, jaise email bhejna
            Console.WriteLine($"[EVENT TRIGGERED]: Welcome email sent to {e.UserEmail} at {e.TimeStamp}");
        }
    }
}